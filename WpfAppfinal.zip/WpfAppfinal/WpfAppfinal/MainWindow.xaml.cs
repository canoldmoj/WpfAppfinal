﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace WpfAppfinal
{
    // Recipe class
    public class Recipe
    {
        public string RecipeName { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
        public List<string> Steps { get; set; } = new List<string>();
    }

    // Ingredient class
    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
    }

    // RecipeManagement class
    public class RecipeManagement
    {
        private List<Recipe> recipes;
        private Dictionary<string, Dictionary<string, double>> originalQuantities;

        public RecipeManagement()
        {
            recipes = new List<Recipe>();
            originalQuantities = new Dictionary<string, Dictionary<string, double>>();
        }

        public void AddRecipe(Recipe recipe)
        {
            // Store original quantities before adding
            if (!originalQuantities.ContainsKey(recipe.RecipeName))
            {
                var ingredientQuantities = new Dictionary<string, double>();
                foreach (var ingredient in recipe.Ingredients)
                {
                    ingredientQuantities[ingredient.Name] = ingredient.Quantity;
                }
                originalQuantities[recipe.RecipeName] = ingredientQuantities;
            }

            recipes.Add(recipe);
        }

        public List<Recipe> GetRecipeList()
        {
            return recipes.OrderBy(r => r.RecipeName).ToList();
        }

        public Recipe GetRecipeByName(string recipeName)
        {
            return recipes.FirstOrDefault(r => r.RecipeName.Equals(recipeName, StringComparison.OrdinalIgnoreCase));
        }

        public void ScaleRecipe(string recipeName, double scaleFactor)
        {
            var recipe = GetRecipeByName(recipeName);
            if (recipe != null)
            {
                foreach (var ingredient in recipe.Ingredients)
                {
                    ingredient.Quantity *= scaleFactor;
                }
            }
        }

        public void ResetQuantities(string recipeName)
        {
            var recipe = GetRecipeByName(recipeName);
            if (recipe != null && originalQuantities.ContainsKey(recipeName))
            {
                var originalQty = originalQuantities[recipeName];
                foreach (var ingredient in recipe.Ingredients)
                {
                    if (originalQty.ContainsKey(ingredient.Name))
                    {
                        ingredient.Quantity = originalQty[ingredient.Name];
                    }
                }
            }
        }

        public List<Recipe> FilterByIngredient(string ingredientName)
        {
            return recipes.Where(r => r.Ingredients.Any(i =>
                i.Name.Equals(ingredientName, StringComparison.OrdinalIgnoreCase))).ToList();
        }

        public List<Recipe> FilterByFoodGroup(string foodGroup)
        {
            return recipes.Where(r => r.FoodGroup != null &&
                r.FoodGroup.Equals(foodGroup, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        public List<Recipe> FilterByCalories(int maxCalories)
        {
            return recipes.Where(r => r.Calories <= maxCalories).ToList();
        }
    }

    // MainWindow class (UI)
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private RecipeManagement recipeManagement;
        private ObservableCollection<Recipe> _displayedRecipes;

        public ObservableCollection<Recipe> DisplayedRecipes
        {
            get => _displayedRecipes;
            set
            {
                _displayedRecipes = value;
                OnPropertyChanged(nameof(DisplayedRecipes));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public MainWindow()
        {
            InitializeComponent();

            // Set the DataContext to this window for binding
            this.DataContext = this;

            recipeManagement = new RecipeManagement();
            DisplayedRecipes = new ObservableCollection<Recipe>();

            // Set initial scale factor selection
            if (ScaleFactorComboBox.Items.Count > 0)
                ScaleFactorComboBox.SelectedIndex = 0;

            UpdateDisplayedRecipes();
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private void ScaleFactorComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Input validation
                if (string.IsNullOrWhiteSpace(RecipeNameTextBox.Text))
                {
                    MessageBox.Show("Please enter a recipe name.", "Input Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(CaloriesTextBox.Text) ||
                    !double.TryParse(CaloriesTextBox.Text, out double calories) ||
                    calories < 0)
                {
                    MessageBox.Show("Please enter valid calories (positive number).", "Input Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Create a new recipe from the input fields
                var recipe = new Recipe
                {
                    RecipeName = RecipeNameTextBox.Text.Trim(),
                    Calories = calories,
                    FoodGroup = FoodGroupTextBox.Text?.Trim() ?? "",
                    Ingredients = new List<Ingredient>(),
                    Steps = new List<string>()
                };

                // Add ingredients to the recipe with error handling
                if (!string.IsNullOrWhiteSpace(IngredientsTextBox.Text))
                {
                    foreach (var ingredientLine in IngredientsTextBox.Text.Split('\n'))
                    {
                        var ingredientText = ingredientLine.Trim();
                        if (!string.IsNullOrWhiteSpace(ingredientText))
                        {
                            var parts = ingredientText.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                            if (parts.Length >= 3)
                            {
                                // Try to parse quantity - handle different formats
                                string quantityStr = parts[1];
                                if (double.TryParse(quantityStr, out double quantity))
                                {
                                    // The rest of the parts are the unit
                                    string unit = string.Join(" ", parts.Skip(2));

                                    var ingredient = new Ingredient
                                    {
                                        Name = parts[0],
                                        Quantity = quantity,
                                        Unit = unit
                                    };
                                    recipe.Ingredients.Add(ingredient);
                                }
                            }
                        }
                    }
                }

                // Add steps to the recipe
                if (!string.IsNullOrWhiteSpace(StepsTextBox.Text))
                {
                    foreach (var stepText in StepsTextBox.Text.Split('\n'))
                    {
                        var step = stepText.Trim();
                        if (!string.IsNullOrWhiteSpace(step))
                        {
                            recipe.Steps.Add(step);
                        }
                    }
                }

                // Check if recipe already exists
                if (recipeManagement.GetRecipeByName(recipe.RecipeName) != null)
                {
                    MessageBox.Show($"A recipe with name '{recipe.RecipeName}' already exists.", "Duplicate Recipe",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Add the recipe to the management class
                recipeManagement.AddRecipe(recipe);

                // Clear input fields
                RecipeNameTextBox.Clear();
                CaloriesTextBox.Clear();
                FoodGroupTextBox.Clear();
                IngredientsTextBox.Clear();
                StepsTextBox.Clear();

                UpdateDisplayedRecipes();

                MessageBox.Show($"Recipe '{recipe.RecipeName}' added successfully!", "Success",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding recipe: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FilterTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateDisplayedRecipes();
        }

        private void ScaleRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (RecipeListBox.SelectedItem is Recipe selectedRecipe)
                {
                    if (ScaleFactorComboBox.SelectedItem is ComboBoxItem selectedItem)
                    {
                        // Safely parse the scale factor
                        string scaleText = selectedItem.Content.ToString().Replace("x", "").Trim();
                        if (double.TryParse(scaleText, out double scaleFactor) && scaleFactor > 0)
                        {
                            recipeManagement.ScaleRecipe(selectedRecipe.RecipeName, scaleFactor);
                            UpdateDisplayedRecipes();
                            MessageBox.Show($"Recipe '{selectedRecipe.RecipeName}' scaled by {scaleFactor}x",
                                "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        else
                        {
                            MessageBox.Show("Invalid scale factor selected.", "Error",
                                MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a scale factor.", "Selection Required",
                            MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Please select a recipe to scale.", "Selection Required",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error scaling recipe: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ResetQuantitiesButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (RecipeListBox.SelectedItem is Recipe selectedRecipe)
                {
                    recipeManagement.ResetQuantities(selectedRecipe.RecipeName);
                    UpdateDisplayedRecipes();
                    MessageBox.Show($"Quantities for '{selectedRecipe.RecipeName}' reset to original values.",
                        "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Please select a recipe first.", "No Selection",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error resetting quantities: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DisplayRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (RecipeListBox.SelectedItem is Recipe selectedRecipe)
                {
                    var recipeDetails = $"Name: {selectedRecipe.RecipeName}\n" +
                                        $"Calories: {selectedRecipe.Calories}\n" +
                                        $"Food Group: {selectedRecipe.FoodGroup}\n" +
                                        "\nIngredients:\n";

                    if (selectedRecipe.Ingredients != null && selectedRecipe.Ingredients.Any())
                    {
                        foreach (var ingredient in selectedRecipe.Ingredients)
                        {
                            recipeDetails += $"{ingredient.Name} - {ingredient.Quantity} {ingredient.Unit}\n";
                        }
                    }
                    else
                    {
                        recipeDetails += "No ingredients available.\n";
                    }

                    recipeDetails += "\nSteps:\n";

                    if (selectedRecipe.Steps != null && selectedRecipe.Steps.Any())
                    {
                        for (int i = 0; i < selectedRecipe.Steps.Count; i++)
                        {
                            recipeDetails += $"{i + 1}. {selectedRecipe.Steps[i]}\n";
                        }
                    }
                    else
                    {
                        recipeDetails += "No steps available.\n";
                    }

                    MessageBox.Show(recipeDetails, $"Recipe Details - {selectedRecipe.RecipeName}",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Please select a recipe first.", "No Selection",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error displaying recipe: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ClearDataButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var result = MessageBox.Show("Are you sure you want to clear all recipe data? This action cannot be undone.",
                    "Confirm Clear", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    recipeManagement = new RecipeManagement();
                    UpdateDisplayedRecipes();
                    MessageBox.Show("All recipe data cleared.", "Success",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error clearing data: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateDisplayedRecipes()
        {
            try
            {
                if (recipeManagement == null) return;

                var filterText = FilterTextBox?.Text?.ToLower() ?? "";
                var filterType = GetCurrentFilterType();

                IEnumerable<Recipe> filteredRecipes;

                switch (filterType)
                {
                    case "Ingredient":
                        filteredRecipes = string.IsNullOrEmpty(filterText)
                            ? recipeManagement.GetRecipeList()
                            : recipeManagement.FilterByIngredient(filterText);
                        break;
                    case "Food Group":
                        filteredRecipes = string.IsNullOrEmpty(filterText)
                            ? recipeManagement.GetRecipeList()
                            : recipeManagement.FilterByFoodGroup(filterText);
                        break;
                    case "All":
                    default:
                        filteredRecipes = string.IsNullOrEmpty(filterText)
                            ? recipeManagement.GetRecipeList()
                            : recipeManagement.GetRecipeList()
                                .Where(recipe =>
                                    (recipe.RecipeName?.ToLower().Contains(filterText) ?? false) ||
                                    (recipe.FoodGroup?.ToLower().Contains(filterText) ?? false) ||
                                    (recipe.Ingredients?.Any(i =>
                                        i.Name?.ToLower().Contains(filterText) ?? false) ?? false));
                        break;
                }

                // Clear and update the Observable Collection
                DisplayedRecipes.Clear();
                foreach (var recipe in filteredRecipes)
                {
                    DisplayedRecipes.Add(recipe);
                }

                // Debug output to verify recipes are being added
                Console.WriteLine($"Recipes in DisplayedRecipes: {DisplayedRecipes.Count}");
                foreach (var recipe in DisplayedRecipes)
                {
                    Console.WriteLine($" - {recipe.RecipeName}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating recipes: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string GetCurrentFilterType()
        {
            try
            {
                if (FilterComboBox?.SelectedItem is ComboBoxItem selectedItem)
                {
                    return selectedItem.Content?.ToString() ?? "All";
                }
                return "All";
            }
            catch
            {
                return "All";
            }
        }

        private void FilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                // Only proceed if the controls are initialized and this is a user action
                if (FilterTextBox == null || FilterComboBox == null || e.AddedItems == null)
                    return;

                // Clear the filter text when filter type changes
                FilterTextBox.Clear();

                // Update recipes based on new filter type
                UpdateDisplayedRecipes();
            }
            catch (Exception ex)
            {
                // Log but don't show message for this minor error
                System.Diagnostics.Debug.WriteLine($"Filter combo box error: {ex.Message}");
            }
        }
    }
}